<?php $this->load->view('includes/header');?>
<body style="background:#f2f2f2;">
<div class="container">
<h1>&nbsp;</h1>
    <h1>&nbsp;</h1>
    <div class="row ">
    <div class="col-4  offset-md-4">
        <h1 class="text-center">login page</h1>
        <br/>
    </div>
        <div class="col-4 offset-md-4 border shadow-lg">
        
<form method="post" action="<?php echo base_url(); ?>MainLogin/login_validation">
<p>&nbsp;</p>
<p>&nbsp;</p>
    <div class="form-group">
        <!-- <label for="username">Username:</label> -->
        <input type="text" name="username" class="form-control" placeholder="Username">
        <span class="text-danger"><?php echo form_error('username'); ?></span>             
    </div>
    <div class="form-group">
        <!-- <label for="password">Password:</label> -->
        <input type="password" name="password" class="form-control" placeholder="Password">
        <span class="text-danger"><?php echo form_error('password'); ?></span>  
    </div>
    <div class="form-group">
        <input type="submit" name="insert" value="login" class="float-right btn btn btn-outline-dark ">
        <?php 
         echo '<label class="text-danger">'.$this->session->flashdata

         ("error").'</label>';  ?>
    </div> 
    <p>&nbsp;</p>
</form>
        </div>
    </div>
</div>

</body>