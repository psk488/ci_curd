<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Crud_model extends CI_Model {
    public function __construct() {
        $this->load->database();
    }

    function createData(){
        $data = array(
            'name'=> $this->input->post('name'),
            'dob'=> $this->input->post('dob'),
            'contact'=> $this->input->post('contact'),
        );
        $this->db->set($data);
        $this->db->insert('ci_tbl',$data);
    }

    function getAllData(){
        $query = $this->db->query('select * from ci_tbl');
        return $query->result();
    }
    function getData($id){
        $query= $this->db->query('select * from ci_tbl where `id`='.$id);
        return $query->row();
    }
    function updateData($id){
       $data = array(
        'name'=> $this->input->post('name'),
        'dob'=> $this->input->post('dob'),
        'contact'=> $this->input->post('contactno'),
       );
       $this->db->set($data);
       $this->db->where('id',$id);
       $this->db->update('ci_tbl',$data);
    }
    function deleteData($id) {
        $this->db->where('id', $id);
        $this->db->delete('ci_tbl');
    }
} 